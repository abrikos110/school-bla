#ifndef STACK_H
#define STACK_H

#include "list.hpp"

template<typename T>
struct stack {
    list<T> lst;

    void push(T &&value);
    T pop();
};

#include "stack.cpp"

#endif

