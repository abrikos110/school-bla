#ifndef QUEUE_H
#define QUEUE_H

template<typename T>
struct queue {
    list<T> lst;

    void push(T &&value);
    T pop();
};

#include "queue.cpp"

#endif

